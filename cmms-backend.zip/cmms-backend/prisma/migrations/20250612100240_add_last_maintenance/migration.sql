-- AlterTable
ALTER TABLE "Equipment" ADD COLUMN "lastMaintenance" DATETIME;
